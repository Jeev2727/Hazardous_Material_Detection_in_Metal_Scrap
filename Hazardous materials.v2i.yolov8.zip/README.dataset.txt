# Hazardous materials > 2025-05-09 1:10pm
https://universe.roboflow.com/jeevanworkspace/hazardous-materials-95ryp

Provided by a Roboflow user
License: CC BY 4.0

