from flask import Flask, render_template, request, send_from_directory
import os
from ultralytics import YOLO
from PIL import Image
import numpy as np
import cv2
import uuid

app = Flask(__name__)
UPLOAD_FOLDER = 'static/uploads'
OUTPUT_FOLDER = 'static/outputs'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(OUTPUT_FOLDER, exist_ok=True)

# Load model
model = YOLO("/Users/mandalajeevan/Downloads/hazardous_site/yolov8_model.pt")

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/upload-image", methods=["POST"])
def upload_image():
    file = request.files['image']
    file_id = str(uuid.uuid4())
    img_path = os.path.join(UPLOAD_FOLDER, file_id + "_" + file.filename)
    file.save(img_path)

    # Inference
    img = Image.open(img_path).convert("RGB")
    results = model.predict(np.array(img), save=False)[0]

    # Save result image
    output_path = os.path.join(OUTPUT_FOLDER, file_id + "_result.jpg")
    result_img = Image.fromarray(results.plot())
    result_img.save(output_path)

    # Count objects
    counts = {}
    for cls_id in results.boxes.cls.cpu().numpy():
        name = results.names[int(cls_id)]
        counts[name] = counts.get(name, 0) + 1

    return {
        "output_image": output_path,
        "counts": counts
    }

@app.route("/upload-video", methods=["POST"])
def upload_video():
    file = request.files['video']
    file_id = str(uuid.uuid4())
    input_path = os.path.join(UPLOAD_FOLDER, file_id + "_" + file.filename)
    output_path = os.path.join(OUTPUT_FOLDER, file_id + "_processed.mp4")
    file.save(input_path)

    cap = cv2.VideoCapture(input_path)
    width = int(cap.get(3))
    height = int(cap.get(4))
    fps = cap.get(cv2.CAP_PROP_FPS)
    out = cv2.VideoWriter(output_path, cv2.VideoWriter_fourcc(*'mp4v'), fps, (width, height))

    counts = {}

    while True:
        ret, frame = cap.read()
        if not ret:
            break
        results = model.predict(frame, save=False)[0]
        out.write(results.plot())

        for cls_id in results.boxes.cls.cpu().numpy():
            name = results.names[int(cls_id)]
            counts[name] = counts.get(name, 0) + 1

    cap.release()
    out.release()

    return {
        "output_video": output_path,
        "counts": counts
    }

@app.route('/static/<path:path>')
def send_static(path):
    return send_from_directory('static', path)

if __name__ == "__main__":
    app.run(debug=True)
